#include<stdio.h>

int main(){
    int x = sqrt(16);
    printf("%d", x);
    return 0;
}